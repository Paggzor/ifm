export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:`pwd`/gtest_bin
