The firmware files have been moved to the
[o3d3xx-firmware](https://github.com/lovepark/o3d3xx-firmware) repository.